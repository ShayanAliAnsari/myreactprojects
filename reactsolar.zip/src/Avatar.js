 import React, { Component } from 'react';
// import React from 'react-dom';
import  './Avatar.css';
import Avatarlist from './Avatarlist';
import 'tachyons';

// const Avatar = (props)=>{


//     return (
//             <div>
//             <h1>Welcome to My First React App</h1>
//             <Avatarlist id="1" name="Hammad Ayoob" work="Python Developer"/>
//             <Avatarlist id="1" name="Zeeshan" work="Javascript Developer"/>
//             <Avatarlist id="1" name="Mohib Bin Wasey" work="Android Developer"/>
//             <Avatarlist id="1" name="Shayan Ali" work="React Developer"/>
//             <button> Click Now !</button>
//            </div>
//             )
//     }
    class Avatar extends Component{

        render()
        {

            return (
                <div className="avatar tc bg-light-gray">
                <div>
                <h1 className="avatar tc">Welcome to My First React App</h1>
                <Avatarlist id="1" name="Hammad Ayoob" work="Python Developer"/>
                <Avatarlist id="1" name="Zeeshan" work="Javascript Developer"/>
                <Avatarlist id="1" name="Mohib Bin Wasey" work="Android Developer"/>
                <Avatarlist id="1" name="Shayan Ali" work="React Developer"/>
               
               </div>
               <button> Click Now !</button>
               </div>
                )
        }
    }
export default Avatar;